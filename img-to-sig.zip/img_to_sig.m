%% FROG
% This program takes an image and converts it into a digital signal for
% acoustic and radio transmissions by:
% 1) Loading desired image and signal parameters.
% 2) Creating an Output folder if none exists.
% 3) Flipping, grayscale-ing, and resizing the image to look its best.
% 4) Editing the contrast logarithmically.
% 5) IFFT to convert from frequency domain to time domain.
% 6) Assembling signal and save it to the Output folder.
%
% 8/22/24, Ky
clear; clc; close all;
current_dir = pwd;

%% USER INPUT -------------------------------------------------------------
fprintf("HI!! WE WILL CREATE COOL IMAGE SIGNAL TXT FILE [TM]\nLOVE,\nKY\n\n");
disp("DEFAULT = 192000 Hz");
fs = input("Desired Output Sampling Rate: ");
if isempty(fs)
    fs = 192000;
end
disp("DEFAULT = 24000 Hz");
fc = input("Desired Center Frequency: ");
if isempty(fc)
    fc = 24000;
end
disp("DEFAULT = 12000 Hz");
bw = input("Desired Bandwidth: ");      
if isempty(bw)
    bw = 12000;
end
disp("REMINDER: black is an absence of frequency/color... :)")
img_path = input("Please provide the path to an image (don't include quotation marks): ",'s');
if isempty(img_path)
    disp("[ERROR] path required >:(");
    return;
end
disp("DEFAULT = 'im-too-good-to-name-my-files'");
filename = input("What to name the generated files? ",'s');
if isempty(filename)
    filename = "im-too-good-to-name-my-files";
end
tic;

%% DIRECTORY CREATION -----------------------------------------------------
% I want to make dozens of these and they need to be organized.
if ~exist(fullfile(current_dir,"output"), "dir")
    mkdir(fullfile(current_dir,"output"));
end

%% LOAD IMAGE -------------------------------------------------------------
disp("[LOADING IMG]");
raw_img = imread(img_path);
gray_img = flip(255-rgb2gray(raw_img));
[height, width] = size(gray_img);

%% RESTRUCTURE AND ENHANCEMENT --------------------------------------------
% About 3.5-5.5% of bandwidth seems ideal for the height in pixels. It also
% cuts down on signal time.
disp("[ENHANCING]");
hz_per_pixel = round(bw/height);
if 1/hz_per_pixel < 0.035
    rescale = 0.035*bw/height;
    gray_img = imresize(gray_img, rescale,"bilinear");
    [height, width] = size(gray_img);
    hz_per_pixel = round(bw/height);
end
if 1/hz_per_pixel > 0.055
    rescale = 0.05*bw/height;
    gray_img = imresize(gray_img, rescale,"bilinear");
    [height, width] = size(gray_img);
    hz_per_pixel = round(bw/height);
end
% Padding with zeros places the image into the correct bandwidth.
below_padding = zeros(round((fs - fc - 0.5*bw)/hz_per_pixel),1);
above_padding = zeros(round((fc - 0.5*bw)/hz_per_pixel),1);
img_mat = zeros(height+length(above_padding)+length(below_padding),width);
enhanced_img = zeros(size(gray_img));
for w=1:width
    for h=1:height
        % Spectrograms display logarithmic color, so we can edit the
        % contrast logarithmicly :D
        enhanced_img(h,w) = 10^(double(gray_img(h,w))/175);
    end
    img_mat(:,w) = [above_padding;enhanced_img(:,w);below_padding];
end

%% IFFT, ETC --------------------------------------------------------------
disp("[INVERSE FFT]");
% Frequency steps with intensity value -> time steps with frequency value
sig_mat = ifft(img_mat);
sig = sig_mat(:,1);
for w=1:width
    sig = [sig(:,1); sig_mat(:,w)];
end
sig = sig/max(abs((sig)));                                  % Normalization
figure;
spectrogram(sig,bw,1,2000,fs,'yaxis');
ylim([fc-0.5*bw, fc+0.5*bw]/1000);

%% SAVING -----------------------------------------------------------------
disp("[SAVING]");
txt_fname = current_dir+"\output\"+filename+".txt";
fileID = fopen(txt_fname,'wt');
nbytes = fprintf(fileID,'%1.8f\n', sig);
fclose(fileID);

%% END MESSAGE
fprintf("Wow that's a %g s long signal!", length(sig)/fs);
fprintf("\nFind the output files located in the output folder!\nDon't " + ...
    "forget to zoom in on that spectrogram <3\n");
toc;
